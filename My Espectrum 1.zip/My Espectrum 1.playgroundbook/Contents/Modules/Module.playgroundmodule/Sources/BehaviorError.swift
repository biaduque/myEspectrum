

// Code inside modules can be shared between pages and other source files.
import UIKit

open class BehaviorError: UIViewController {
    
    var screen: Int = 0
    var vectorSceenes: [String] = ["error"]
    let minhaView = UIView()
    
    open override func loadView() {
        // Carregar imagem
        var img = UIImage(named: vectorSceenes[screen])
        var background = img //UIImage
        var imgView = UIImageView(image: background)
        // Mostrar a imagem
        minhaView.addSubview(imgView)
        // Posição do background
        imgView.layer.masksToBounds = true
        imgView.contentMode = .scaleAspectFill
        imgView.translatesAutoresizingMaskIntoConstraints = false
        imgView.leftAnchor.constraint(equalTo: minhaView.leftAnchor).isActive = true
        imgView.rightAnchor.constraint(equalTo: minhaView.rightAnchor).isActive = true
        imgView.topAnchor.constraint(equalTo: minhaView.topAnchor).isActive = true
        imgView.heightAnchor.constraint(equalTo: minhaView.heightAnchor).isActive = true
        imgView.widthAnchor.constraint(equalTo:minhaView.widthAnchor).isActive = true
        self.view = minhaView
    }
}



