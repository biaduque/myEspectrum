//#-hidden-code
//Made By : Beatriz Duque :)

import PlaygroundSupport
import Module
let end = Conclusion()
PlaygroundPage.current.setLiveView(end)

//#-end-hidden-code

/*:
 
 # 🧩  Conclusion  🧩
 ## Thank you for playing and learning with us today! It is important to remember
 
 💙 Autism is not a disease! It is a neurological disorder that affects the nervous system.
 
 
 💙 This playground teaches some things about the autistic spectrum, but remember: each person is unique and therefore many things can vary
 
 
 💙 Autism does not limit anyone! Many brilliant minds like Daryl Hannah, Lionel Messi, Heather Kuzmich, Greta Thunberg and many others have Autism or Asperger (a variant syndrome of Autism).

 */
