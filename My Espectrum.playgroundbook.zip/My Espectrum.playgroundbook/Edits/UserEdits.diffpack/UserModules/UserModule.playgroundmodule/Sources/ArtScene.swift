

import UIKit
import SpriteKit

public class ArtScene: SKScene{
    var particles: [Particle] = []
    var particlesQtd: Int = 100
    var colors: [UIColor] = [#colorLiteral(red: 0.9023433924, green: 0.2320581675, blue: 0.4786583185, alpha: 1.0),#colorLiteral(red: 0.0, green: 0.2595015466, blue: 0.6651419401, alpha: 1.0),#colorLiteral(red: 0.9994536042, green: 0.7040986419, blue: 0.245582819, alpha: 1.0),#colorLiteral(red: 0.4653213024, green: 0.7332682014, blue: 0.2536376119, alpha: 1.0)]
    
    public override func didMove(to view: SKView) {
        //essa funcao precisa do parametro view que é da classe pai
        //didMove comeca a mostrar coisas na tela 
        super.didMove(to: view)
        
        //variavel que ja existe em SKScene
        backgroundColor = #colorLiteral(red: -0.26969218254089355, green: 0.5599241852760315, blue: 0.7234257459640503, alpha: 1.0)
        
        for i in 0..<particlesQtd{
            var p = Particle(x: 0,
                             y: 0,
                             color: colors[Int.random(in: 0..<colors.count)],
                             radius: CGFloat.random(in: 5...20), 
                             vx: CGFloat.random(in: -3...3),
                             vy: CGFloat.random(in: -3...3))
            self.addChild(p.getShape())
            particles.append(p)
        }
    }
    
    public override func didChangeSize(_ oldSize: CGSize) {
        //criando o ponto no centro da tela = self.size.width
        //.count conta o tamanho do array
        for i in 0..<particles.count{
            if self.size.width>=20{
                particles[i].x = CGFloat.random(in: particles[i].radius...self.size.width-particles[i].radius)
                particles[i].y = CGFloat.random(in: particles[i].radius...self.size.height-particles[i].radius)
            }
        }
    }
    
    func draw(){
        //remove tudo o que tem na tela e depois coloca tudo novamente
        //funciona como stopmotion
        self.removeAllChildren()
        for i in 0..<particles.count{
            self.addChild(particles[i].getShape())
        }
    }
    public override func update(_ currentTime: TimeInterval){
        for i in 0..<particles.count{
            //muda as posicoes para reescrever elas
            if particles[i].x <= particles[i].radius || particles[i].x >= self.size.width - particles[i].radius{
                particles[i].vx *= -1
            }
            if particles[i].y <= particles[i].radius || particles[i].y >= self.size.height - particles[i].radius{
                particles[i].vy *= -1
            }
            particles[i].x += particles[i].vx
            particles[i].y += particles[i].vy
        }
        draw()
    }
}

/*
 anotacoes para serem acrescentadas no didMov
 //criando o no: nome: tipo = metodo (tipo do metodo: und em pixel)
 var node1: SKShapeNode = SKShapeNode(circleOfRadius: 20)
 //adiciona na cena
 //spriteKit = 0.0 a esquerda inferior
 node1.position = CGPoint(x:100, y:200)
 //node1.position.x = 100 (podemos mudar uma a um)
 node1.lineWidth = 0
 node1.fillColor = #colorLiteral(red: 0.9977119565, green: 0.7947712541, blue: 0.2450369, alpha: 1.0)
 self.addChild(node1)
 //var node3: SKShapeNode = SKShapeNode(rectOf: CGSize(width: 40, height: 80))
 //node3.position = CGPoint(x:300,y:300)
 //self.addChild(node3)
 
 //criando um no com uma foto
 var avatar: SKSpriteNode = SKSpriteNode(imageNamed:"avatar.png")
 avatar.setScale(0.5)
 avatar.position.x = (self.size.width)/2
 avatar.position.y = (self.size.height)/2
 self.addChild(avatar)
 
 
 */
