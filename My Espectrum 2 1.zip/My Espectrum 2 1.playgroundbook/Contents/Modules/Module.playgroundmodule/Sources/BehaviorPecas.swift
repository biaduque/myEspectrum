import SpriteKit
import UIKit

open class GameScene: SKScene {
    var passou = false //se torna true apenas quando todos os itens sao encaixados em suas respectivas caixas
    var proxima = false //passa para as proximas telas se houver passado de fase
    var screen: Int = 0
    var i: Int = 0
    var finish: SKSpriteNode = SKSpriteNode(imageNamed: "finish")

    
    //var no: SKSpriteNode = SKSpriteNode(imageNamed: "heart")
    var pecas: [Pecas] = [] //criando vetor de pecas
    var background = SKSpriteNode(imageNamed: "13.2")
    var backs: [String] = ["14","15"]
    var background2 = SKSpriteNode(imageNamed: "14")
    //guardando nomes das pecas para futuras referencias
    var pecasnomes = [Optional("azul1"),Optional("azul2"),Optional("azul3"),Optional("amarelo1"),Optional("amarelo2"),Optional("amarelo3"),Optional("vermelho1"),Optional("vermelho2"),Optional("vermelho3")]
    //caixas vazias que vao receber as pecas
    var caixaAzul: [String] = ["","",""]
    var caixaVermelha: [String] = ["","",""]
    var caixaAmarela: [String] = ["","",""]
    
    open override func didMove(to view: SKView) {
        
        background.position = CGPoint(x: frame.size.width/2 , y: frame.size.height/2)
        addChild(background)
        
            //definindo botao para finalizar
        finish.anchorPoint = CGPoint(x: 0.5, y: 0.5)
        finish.position = CGPoint(x: 330, y: -512)
        finish.name = "finish"
        
        for i in 0..<9{
            var x = CGFloat.random(in: -315...328)
            var y = CGFloat.random(in: 268...485)
            
            while ((x <= 324 && x >= -315) == false ) && ((y <= 485 && y >= 268) == false ){
                x = CGFloat.random(in: -315...328)
                y = CGFloat.random(in: 268...485)
            }
            var no = Pecas(x: x, y: y, indice: i, locationx: 0.0, locationy: 0.0)
            pecas.append(no)
        }
        self.anchorPoint = CGPoint(x:0.5,y:0.5)
        background.size = CGSize(width: 1679/2, height: 2350/2)
        background2.size = CGSize(width: 1679/2, height: 2350/2)
        

    }
    public override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        //funcao de toque no botao estatico
        if let touch = touches.first{
            let location = touch.location(in: self)
            var escolhido = atPoint(location).name?.description
            if escolhido == Optional("finish"){
                if screen == 0{
                    //seta o primeiro clique
                    screen+=1
                }
                else{
                    //seta o segundo clique atraves do codigo
                    screen = 100
                }
                proxima = true
            }
        }
    }
    open override func touchesMoved(_ touches: Set<UITouch>, with event: UIEvent?) {
        
        for touch in touches {
            let location = touch.location(in: self)
            var nos = nodes(at: location)
            //define qual foi o no clicado
            var escolhido = atPoint(location).name?.description
            //print(escolhido)
            
                //seta  a imagem que vai mover de acordo com o no que foi clicado
            
            for j in 0..<9{
                if escolhido == pecasnomes[j]{
                    i = j
                }
            }
            pecas[i].x = location.x
            pecas[i].y = location.y
            
            //var escolheux = atPoint(location).position.x
            //var escolheuy = atPoint(location).position.y
            
            //definindo posicao da caixa azul
            if i >= 0 && i<=2 {
                if (self.pecas[i].x <= 220 && self.pecas[i].x >= -70) && self.pecas[i].y >= -350 && self.pecas[i].y <= -150{
                    if escolhido == Optional("azul1") {
                        caixaAzul[0] = "OK"
                    }
                    else if escolhido == Optional("azul2") {
                        caixaAzul[1] = "OK"
                    }
                    else{
                        caixaAzul[2] = "OK"
                    }
                }
            }
            else if i>=6 && i<=8 {
                
                //definindo posicao da caixa vermelha
                if (self.pecas[i].x <= -143 && self.pecas[i].x >= -309) && self.pecas[i].y >= -26 && self.pecas[i].y <= 75{
                    if escolhido == Optional("vermelho1") {
                        caixaVermelha[0] = "OK"
                    }
                    else if escolhido == Optional("vermelho2") {
                        caixaVermelha[1] = "OK"
                    }
                    else{
                        caixaVermelha[2] = "OK"
                    }
                }
            }
            else{
                //definindo posicao da caixa amarela
                if (self.pecas[i].x <= 292 && self.pecas[i].x >= 80) && self.pecas[i].y >= -5 && self.pecas[i].y <= 135{
                    if escolhido == Optional("amarelo1") {
                        caixaAmarela[0] = "OK"
                    }
                    else if escolhido == Optional("amarelo2") {
                        caixaAmarela[1] = "OK"
                    }
                    else{
                        caixaAmarela[2] = "OK"
                    }
                }
            }
            //if que verifica se todos os itens foram posicionados em suas respectivas caixas
            if ((caixaAzul[0]  == "OK") && (caixaAzul[1] == "OK") && (caixaAzul[2] == "OK")) && ((caixaAmarela[0]  == "OK") && (caixaAmarela[1] == "OK") && (caixaAmarela[2] == "OK")) && ((caixaVermelha[0]  == "OK") && (caixaVermelha[1] == "OK") && (caixaVermelha[2] == "OK")) {
                passou = true
            }
        }
    }
    
    
    func draw(){
        if proxima == true{
            self.removeAllChildren()
            if screen > 0 {
                //primeiro clique no botao finish
                background2 = SKSpriteNode(imageNamed: backs[0])
                background2.size = CGSize(width: 1679/2, height: 2350/2)
                self.addChild(background2)
                self.addChild(finish)
            }
            if screen == 100{
                //segundo clique no botao finish
                self.removeAllChildren()
                background2 = SKSpriteNode(imageNamed: backs[1])
                background2.size = CGSize(width: 1679/2, height: 2350/2)
                self.addChild(background2)
                var caixaAzul: [String] = ["","",""]
                var caixaVermelha: [String] = ["","",""]
                var caixaAmarela: [String] = ["","",""]
                passou = false
            }
        }
        else{
            //cai nesse else se a pessoa nao tiver passado na fase
            //remove tudo o que tem na tela e depois coloca tudo novamente
            self.removeAllChildren()
            self.addChild(background)
            var no: SKNode
            //self.childNode(withName: "").removeFromParent()
            for j in 0..<9{
                self.addChild(pecas[j].getShape())
            }
            if passou == true{
                self.addChild(finish)
            }
        }

    }
    
    open override func update(_ currentTime: TimeInterval){
        draw()
    }
}

