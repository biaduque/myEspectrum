
// Code inside modules can be shared between pages and other source files.
import UIKit
import AVFoundation

open class Sensory: UIViewController {
    
    
    var screen: Int = 0
    var text: Int = 0
    var count: Int = 0
    var vectorSceenes: [String] = ["16","17","18","19"]
    let buttonText = ["Next","Next"]
    var musics = "music1"  //musica 1: typcal musica 2: atypcal
    let button = UIButton(type: .custom)
    let button2 = UIButton(type: .custom)
    let minhaView = UIView()
    
        //criando botao para audio
    
    var audioPlayer: AVAudioPlayer?
    var playButton: UIButton = UIButton(type: .custom)
    
    open override func loadView() {
        minhaView.backgroundColor = #colorLiteral(red: 0.9214347004890442, green: 0.9214347004890442, blue: 0.9214347004890442, alpha: 1.0)
        // Carregar imagem
        var img = UIImage(named: vectorSceenes[screen])
        var background = img //UIImage
        var imgView = UIImageView(image: background)
        // Mostrar a imagem
        minhaView.addSubview(imgView)
        // Posição do background
        imgView.layer.masksToBounds = true
        imgView.contentMode = .scaleAspectFill
        imgView.translatesAutoresizingMaskIntoConstraints = false
        imgView.leftAnchor.constraint(equalTo: minhaView.leftAnchor).isActive = true
        imgView.rightAnchor.constraint(equalTo: minhaView.rightAnchor).isActive = true
        imgView.topAnchor.constraint(equalTo: minhaView.topAnchor).isActive = true
        imgView.heightAnchor.constraint(equalTo: minhaView.heightAnchor).isActive = true
        imgView.widthAnchor.constraint(equalTo:minhaView.widthAnchor).isActive = true
        
        // Botão
        button.addTarget(self, action: #selector(updateScreenNumber), for: .touchUpInside)
        minhaView.addSubview(button)
        // configurar Botão
        button.showsTouchWhenHighlighted = true
        button.frame = CGRect(x: 0, y: 0, width: 0, height: 0)
        button.setTitle(buttonText[text], for: .normal)
        button.setTitleColor(.white, for: .normal)
        button.backgroundColor = #colorLiteral(red: 0.9998682141, green: 0.8477882147, blue: 0.4652701616, alpha: 1.0)
        button.translatesAutoresizingMaskIntoConstraints = false
        button.topAnchor.constraint(equalTo: imgView.bottomAnchor, constant: -50).isActive = true
        button.rightAnchor.constraint(equalTo: imgView.rightAnchor, constant:-10).isActive = true
        button.widthAnchor.constraint(equalToConstant: 75).isActive = true
        button.layer.cornerRadius = 15
        
        // configurar Botão de voltar
        // configurar Botão2
        if screen >= 1{
            button2.addTarget(self, action: #selector(backScreenNumber), for: .touchUpInside)
            minhaView.addSubview(button2)
            button2.showsTouchWhenHighlighted = true
            button2.frame = CGRect(x: 0, y: 0, width: 0, height: 0)
            button2.setTitle("Back", for: .normal)
            button2.setTitleColor(.white, for: .normal)
            button2.backgroundColor = #colorLiteral(red: 1.0313969850540161, green: 0.8330875635147095, blue: 0.28774523735046387, alpha: 1.0)
            button2.translatesAutoresizingMaskIntoConstraints = false
            button2.topAnchor.constraint(equalTo: imgView.bottomAnchor, constant: -50).isActive = true
            button2.leftAnchor.constraint(equalTo: imgView.leftAnchor, constant: 10).isActive = true
            button2.widthAnchor.constraint(equalToConstant: 75).isActive = true
            button2.layer.cornerRadius = 15
        }
        
        //configurando botao de musica
        if screen == 1 || screen == 2 {
            self.minhaView.addSubview(self.playButton)
            playButton.setTitle("   Play Audio   ", for: .normal)
            playButton.setTitleColor(.white, for: .normal)
            playButton.backgroundColor = #colorLiteral(red: 0.9977119565, green: 0.7947712541, blue: 0.2450369, alpha: 1.0)
            playButton.layer.cornerRadius = 10
            playButton.showsTouchWhenHighlighted = true
            playButton.addTarget(self, action: #selector(tocarSom), for: .touchDown)
            //playButton.frame = CGRectMake(15, -50, 300, 500)
            self.posicionarPlayButton()
            //troca a musica de acordo com o personagem
            if screen == 1{
                musics = "music1"
                //incrementando a variavel que conta a musica que sera tocada
            }
            if screen == 2{
                musics = "music2"
            }
        }
        
        self.view = minhaView
        
    }
    
    
    //func to update screen scenes
    @objc func updateScreenNumber() {
        if text == 0{
            text+=1
        }
        if screen >= 3 {
            screen = 0
        }
        else {
            screen+=1
        }
        loadView()
    }
    
    //func to back screen scenes
    @objc func backScreenNumber() {
        if screen == 0 {
            screen = 0
        }
        else {
            screen-=1
        }
        loadView()
    }
    
    func posicionarPlayButton() {
        self.playButton.translatesAutoresizingMaskIntoConstraints = false
        self.playButton.centerYAnchor.constraint(equalTo: self.view.centerYAnchor).isActive = true
        self.playButton.centerXAnchor.constraint(equalTo: self.view.centerXAnchor).isActive = true
    }
    
    @objc func tocarSom() {
        if let audioFile = Bundle.main.url(forResource: musics, withExtension: "mp3") {
            do {
                try self.audioPlayer = AVAudioPlayer(contentsOf: audioFile)
                self.audioPlayer?.numberOfLoops = 0
                self.audioPlayer?.play()
            } catch {
                print("Erro ao tentar tocar o som: \(error)")
            }
        } else {
            print("Audio não encontrado")
        }
    }
}




