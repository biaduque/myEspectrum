//#-hidden-code
//Made By : Beatriz Duque :)
import PlaygroundSupport
import Module
let communication = Communication() //chamando a classe que foi construida

//#-end-hidden-code

/*:
 
# 2nd Piece: 🧩 Communication
 ### Let's explore the part of the spectrum that involves communication
 Look, a different person came to talk to Bia and Fernando. Bia already knows this person, but Fernando does not know them yet. Shall we help him to greet this person?
 
 Use the commands:
### `To make Bia speak`
    -> communication.makeBiaSpeak()
### `To make Fernando speak`
    -> communication.makeFernandoSpeak()
 
*/


/*:
 ## 🔵 Let's try!
 ### `To make Bia speak`
 */
communication/*#-editable-code*/ /*#-end-editable-code*/

/*:
 ## 🔵 Let's try!
 ### `To make Fernando speak`
 */
communication/*#-editable-code*/ /*#-end-editable-code*/

/*:
 ### 🔵 Now let's see what happens!
*/

//#-hidden-code

PlaygroundPage.current.setLiveView(communication)

//#-end-hidden-code

/*:
 ## Conclusion
 Fernando sometimes finds it difficult to verbalize what he means, so he prefers to show his name tag on his wrist to introduce himself. It is an incredible way that he found to present himself!
*/

//: [🧩 Next Spectrum Piece](@next)
