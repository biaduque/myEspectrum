/*:
# 1st Piece : 🧩 Social Interation
 
 Now Fernando is going to take us on an experiment to get you to know a little bit more about the part of the spectrum that involves SOCIAL INTERACTION.
 His friend Bia has just arrived and wants to talk to him!
     
 See, Fernando knows Bia and wants to talk to her, what could he say?
 Add a sentence below for Fernando talk with Bia!
 Click Next to start!
*/


let talk: String = /*#-editable-code*/ "..." /*#-end-editable-code*/

//#-hidden-code
import PlaygroundSupport
import Module
let social = Social()
social.getText(textB: talk)
PlaygroundPage.current.setLiveView(social)
//#-end-hidden-code

/*:
 # Conclusion 
 Incredible! Now see on the screen some things that we can notice about this part of the spectrum and collect your first Piece.
*/

//: [🧩 Next Spectrum Piece](@next)
