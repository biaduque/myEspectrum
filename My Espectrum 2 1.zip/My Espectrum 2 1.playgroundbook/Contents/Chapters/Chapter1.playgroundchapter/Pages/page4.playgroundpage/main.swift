/*:
 
# 3rd Piece: 🧩 Behavior
 
This part of the spectrum involves behavior. It may be something related to restrictive or repetitive behavior.
 
 Fernando likes to organize his favorite objects and things.
 ## You can see below, here are some of Fernando's objects:
 
 ![objects](objects.png)
 
 ## The importance of Name Tags and Labels
 
 It is important that there are identification tags on each one of them, because for a person within the autistic spectrum, generalizing things is not cool!
 
 For Example:
 
 📗 -> If this is a book
 📕 -> This is a book?
 
 For Fernando, the answer is no! It's not a book! This is because it had already been explained to him that a book was yellow, not red. Therefore, it is important to explain things in a way that does not generalize them.
 
 ### So, Fernando can organize his things through colors and labels, like this

 */

let 🔵 = "My blue ball toy"
let 📘 = "My blue notebook"
let 🚙 = "My blue car toy"

let 🎸 = "My red guitar"
let 📕 = "My red book"
let 🚘 = "My red car toy"

let 💛 = "My yellow heart toy"
let 📒 = "My yellow book"
let 🚖 = "My yellow car toy"

/*:
 
Try to organize things by categories and colors like Fernando. Place the objects organized according to their colors in the reserved spaces below.
 
 These are the objects you need to organize:
 
 let myObjects = [🔵,🎸,💛,🚖,📕,🚘,📘,📒,🚙]
 
 ` # Let's Try! Drag the pieces to their respective boxes on the LiveView!`
 
 */

/*:
 
 ### Follow Fernando to the next part of the spectrum! Let's see how it works for him.

 */

//: [🧩 Next Spectrum Piece](@next)


