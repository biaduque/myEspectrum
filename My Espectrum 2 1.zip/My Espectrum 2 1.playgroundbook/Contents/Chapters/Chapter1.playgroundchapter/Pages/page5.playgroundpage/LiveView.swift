import PlaygroundSupport
import Module
let sounds = Sensory()
PlaygroundPage.current.setLiveView(sounds)
