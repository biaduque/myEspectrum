/*:
 
 # 4th Piece: 🧩  Sensory sensitivity
 Sounds can be different for each type of person, especially for someone on the autistic spectrum. Want to see how it works in practice?

 */

/*:
 

 ## 🎶🎵🎶🎵 Sounds for a typical person 🎶🎵🎶🎵
 First, let's hear how a typical person (who is not on the autistic spectrum) listens to music. Let's listen to music together with Bia! Press the "Play" button to listen to the song along with it.
![](onda1)
 
 ## 🎶🎵🎶🎵 Sounds for an atypical person 🎶🎵🎶🎵
 Now, let's hear how an atypical person (who is on the autistic spectrum) listens to music. Let's listen to music with Fernando! Press the "Play" button to listen to the song along with it.
 ![](onda2)
 
` -> Use the "Next" button to browse through the experience. `
 
` -> Let's listen to a song along with him! Press the "Play" button to listen to it. `

 ## Conclusion
 
 The sounds may be louder, higher or lower for Fernando. He can focus on one sound at a time or sometimes, many sounds end up mixing. Therefore, it is very common for autistic people to use 🎧  Headphones 🎧  to attenuate those loud sounds that cause discomfort.
 
 `These sounds were simulated through the Garage Band app, available on the App Store.`
 */

//: [Conclusion](@next)
