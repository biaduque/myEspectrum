import PlaygroundSupport
import Module
let art = Behavior()
PlaygroundPage.current.setLiveView(art)

