// Code inside modules can be shared between pages and other source files.
import UIKit

open class Conclusion: UIViewController {
    
    
    var screen: Int = 0
    var vectorSceenes: [String] = ["20"]
    let minhaView = UIView()
    
    open override func loadView() {
        minhaView.backgroundColor = #colorLiteral(red: 0.9214347004890442, green: 0.9214347004890442, blue: 0.9214347004890442, alpha: 1.0)
        // Carregar imagem
        var img = UIImage(named: vectorSceenes[screen])
        var background = img //UIImage
        var imgView = UIImageView(image: background)
        // Mostrar a imagem
        minhaView.addSubview(imgView)
        // Posição do background
        imgView.layer.masksToBounds = true
        imgView.contentMode = .scaleAspectFill
        imgView.translatesAutoresizingMaskIntoConstraints = false
        imgView.leftAnchor.constraint(equalTo: minhaView.leftAnchor).isActive = true
        imgView.rightAnchor.constraint(equalTo: minhaView.rightAnchor).isActive = true
        imgView.topAnchor.constraint(equalTo: minhaView.topAnchor).isActive = true
        imgView.heightAnchor.constraint(equalTo: minhaView.heightAnchor).isActive = true
        imgView.widthAnchor.constraint(equalTo:minhaView.widthAnchor).isActive = true
        
        self.view = minhaView
    }
    
}



