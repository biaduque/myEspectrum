import SpriteKit

open class Pecas{
    var pecas = ["azul1","azul2","azul3","amarelo1","amarelo2","amarelo3","vermelho1","vermelho2","vermelho3"]
    
    var x: CGFloat
    var y: CGFloat
    var indice: Int = 0
    var name = ""
    var locationx: CGFloat
    var locationy: CGFloat
    //cria particula generica
    init (){
        x=0
        y=0
        indice = 0
        name = ""
        locationx = 0.0
        locationy = 0.0
    }
    
    init(x: CGFloat, y: CGFloat, indice: Int, locationx: CGFloat, locationy: CGFloat){
        self.x = x
        self.y = y
        self.indice = indice //define o indice da imagem
        self.locationx = locationx
        self.locationy = locationy
    }
    
    func getShape() -> SKSpriteNode {
        var node: SKSpriteNode = SKSpriteNode(imageNamed: pecas[indice])
        node.position = CGPoint(x: self.x, y: self.y)
        node.anchorPoint = CGPoint(x: 0.5, y: 0.5)
        if indice >= 0  && indice <= 2{
            //definindo o grupo das imagens azuis
            node.name = String(pecas[indice])
        }
        else if indice >= 3 && indice <= 5{
            //definindo o grupo das imagens amarelas
            node.name = String(pecas[indice])
        }
        else{
            //definindo o grupo das imagens vermelhas
            node.name = String(pecas[indice])
        }
        
        return node
    }
    func getIndice() -> Int{
        return self.indice
    }
    
    func getLocationX() -> CGFloat{
        return locationx
    }
    
    func getLocationY() -> CGFloat{
        return locationy
    }
    
    func setLocationX(location: CGFloat){
        var locationx: CGFloat
        locationx = location
    }
    
    func setLocationY(location: CGFloat){
        var locationy: CGFloat
        locationy = location
    }
}

