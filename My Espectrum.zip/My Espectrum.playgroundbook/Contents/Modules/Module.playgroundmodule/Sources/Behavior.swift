// Code inside modules can be shared between pages and other source files.
import UIKit

open class Behavior: UIViewController {
    
    
    var screen: Int = 0
    var text: Int = 0
    var vectorSceenes: [String] = ["12","13","14","15"]
    let buttonText = ["Next","Next"]
    let button = UIButton(type: .custom)
    let button2 = UIButton(type: .custom)
    let minhaView = UIView()
    
    open override func loadView() {
        minhaView.backgroundColor = #colorLiteral(red: 0.9214347004890442, green: 0.9214347004890442, blue: 0.9214347004890442, alpha: 1.0)
        // Carregar imagem
        var img = UIImage(named: vectorSceenes[screen])
        var background = img //UIImage
        var imgView = UIImageView(image: background)
        // Mostrar a imagem
        minhaView.addSubview(imgView)
        // Posição do background
        imgView.layer.masksToBounds = true
        imgView.contentMode = .scaleAspectFill
        imgView.translatesAutoresizingMaskIntoConstraints = false
        imgView.leftAnchor.constraint(equalTo: minhaView.leftAnchor).isActive = true
        imgView.rightAnchor.constraint(equalTo: minhaView.rightAnchor).isActive = true
        imgView.topAnchor.constraint(equalTo: minhaView.topAnchor).isActive = true
        imgView.heightAnchor.constraint(equalTo: minhaView.heightAnchor).isActive = true
        imgView.widthAnchor.constraint(equalTo:minhaView.widthAnchor).isActive = true
        
        // Botão
        button.addTarget(self, action: #selector(updateScreenNumber), for: .touchUpInside)
        minhaView.addSubview(button)
        // configurar Botão
        button.frame = CGRect(x: 0, y: 0, width: 0, height: 0)
        button.setTitle(buttonText[text], for: .normal)
        button.setTitleColor(.white, for: .normal)
        button.backgroundColor = #colorLiteral(red: 0.9998682141, green: 0.8477882147, blue: 0.4652701616, alpha: 1.0)
        button.translatesAutoresizingMaskIntoConstraints = false
        button.topAnchor.constraint(equalTo: imgView.bottomAnchor, constant: -50).isActive = true
        button.rightAnchor.constraint(equalTo: imgView.rightAnchor, constant:-10).isActive = true
        button.widthAnchor.constraint(equalToConstant: 75).isActive = true
        button.layer.cornerRadius = 15
        
        // configurar Botão de voltar
        // configurar Botão2
        if screen >= 1{
            button2.addTarget(self, action: #selector(backScreenNumber), for: .touchUpInside)
            minhaView.addSubview(button2)
            button2.frame = CGRect(x: 0, y: 0, width: 0, height: 0)
            button2.setTitle("Back", for: .normal)
            button2.setTitleColor(.white, for: .normal)
            button2.backgroundColor = #colorLiteral(red: 0.9998682141, green: 0.8477882147, blue: 0.4652701616, alpha: 1.0)
            button2.translatesAutoresizingMaskIntoConstraints = false
            button2.topAnchor.constraint(equalTo: imgView.bottomAnchor, constant: -50).isActive = true
            button2.leftAnchor.constraint(equalTo: imgView.leftAnchor, constant: 10).isActive = true
            button2.widthAnchor.constraint(equalToConstant: 75).isActive = true
            button2.layer.cornerRadius = 15
        }
        
        
        self.view = minhaView
    }
    
    
    //func to update screen scenes
    @objc func updateScreenNumber() {
        if text == 0{
            text+=1
        }
        if screen >= 3 {
            screen = 0
        }
        else {
            screen+=1
        }
        loadView()
    }
    
    //func to back screen scenes
    @objc func backScreenNumber() {
        if screen == 0 {
            screen = 0
        }
        else {
            screen-=1
        }
        loadView()
    }
}


