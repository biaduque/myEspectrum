/*:
 # Welcome!
 
 ## 💙 About Me
 My name is Beatriz, but you can call me Bia.

 I have a friend named Fernando who is part of the Autistic Spectrum and he teaches me a lot about it every day. Today, we are inviting you to learn a little more about this as well. What do you think?

 First, I will introduce you to some elements of our adventure today!


 That's me (Bia) and Fernando! We will be represented by these characters:
 
 ### Characters
 ![Characters](characters.png)

 We'll show you a few things, and at the end of each scene, you'll collect a new piece of the spectrum. Each one represents a feature to be discovered. They look like this:
 
 ### The espectrum Pieces 🧩 
 ![Pieces](pieces2.png)

 To discover each piece, simply navigate on each page using the "Next" button. It looks like this:
 
### Button
![button](button.png)

 I think that's it for now! We hope you have fun and learn a lot.
 
 */


//#-hidden-code
//Made By : Beatriz Duque :)
import PlaygroundSupport
import Module
let art = Introduction()
PlaygroundPage.current.setLiveView(art)
//#-end-hidden-code
